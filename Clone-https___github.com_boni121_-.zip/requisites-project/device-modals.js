// Функция для инициализации модальных окон управления устройствами
function initDeviceManagementModals() {
    // Тестовые данные устройств
    const devices = [
        { id: 'a05705f4...', name: 'луцорлорпвыо' },
        { id: '8fdf9c87...', name: 'fdgf' },
        { id: '83c236f9...', name: 'wb2' },
        { id: '23d9a909...', name: 'wd 3 (kratos)' }
    ];

    // DOM элементы
    const devicesModal = document.getElementById('devicesModal');
    const logModal = document.getElementById('logModal');
    const androidAppsModal = document.getElementById('androidAppsModal');
    const qrCodeModal = document.getElementById('qrCodeModal');
    const editDeviceModal = document.getElementById('editDeviceModal');
    const addDeviceModal = document.getElementById('addDeviceModal');
    const devicesList = document.getElementById('devicesList');
    const closeButtons = document.querySelectorAll('.device-close-btn');
    const closeDevicesBtn = document.getElementById('closeDevicesBtn');
    const addDeviceBtn = document.getElementById('addDeviceBtn');
    const fromDateInput = document.getElementById('fromDate');
    const toDateInput = document.getElementById('toDate');
    const fromDateCalendar = document.getElementById('fromDateCalendar');
    const toDateCalendar = document.getElementById('toDateCalendar');
    const applyDatesBtn = document.getElementById('applyDates');
    const okLogBtn = document.getElementById('okLogBtn');
    const okAndroidBtn = document.getElementById('okAndroidBtn');
    const okQrBtn = document.getElementById('okQrBtn');
    const copyQrKeyBtn = document.getElementById('copyQrKey');
    const closeEditBtn = document.getElementById('closeEditBtn');
    const closeAddBtn = document.getElementById('closeAddBtn');

    // Функция для открытия модального окна
    function openModal(modal) {
        if (modal) {
            modal.style.display = 'block';
        }
    }

    // Функция для закрытия модального окна
    function closeModal(modal) {
        if (modal) {
            modal.style.display = 'none';
        }
    }

    // Заполнение списка устройств
    function populateDevicesList() {
        if (!devicesList) return;

        // Очищаем текущее содержимое
        devicesList.innerHTML = '';

        // Добавляем устройства в таблицу
        devices.forEach(device => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${device.id}</td>
                <td>${device.name}</td>
                <td>
                    <button class="device-icon-btn device-message-btn" data-id="${device.id}">
                        <i class="fa-solid fa-message"></i>
                    </button>
                </td>
                <td>
                    <button class="device-icon-btn device-android-btn" data-id="${device.id}">
                        <i class="fa-brands fa-android"></i>
                    </button>
                </td>
                <td>
                    <button class="device-icon-btn device-edit-btn" data-id="${device.id}" data-name="${device.name}">
                        <i class="fa-solid fa-pencil"></i>
                    </button>
                </td>
                <td>
                    <button class="device-icon-btn device-delete-btn" data-id="${device.id}">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </td>
            `;
            devicesList.appendChild(row);
        });

        // Добавляем обработчики событий для кнопок действий
        document.querySelectorAll('.device-message-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const deviceId = this.getAttribute('data-id');
                document.getElementById('logModalTitle').textContent = `Лог сообщений: ${deviceId}`;
                closeModal(devicesModal);
                openModal(logModal);
            });
        });

        document.querySelectorAll('.device-android-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                closeModal(devicesModal);
                openModal(androidAppsModal);
            });
        });

        document.querySelectorAll('.device-edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const deviceId = this.getAttribute('data-id');
                const deviceName = this.getAttribute('data-name');
                document.querySelector('#editDeviceModal .device-id').textContent = deviceId;
                document.getElementById('deviceNameInput').value = deviceName;
                closeModal(devicesModal);
                openModal(editDeviceModal);
            });
        });

        document.querySelectorAll('.device-delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const deviceId = this.getAttribute('data-id');
                const confirmDelete = confirm(`Вы уверены, что хотите удалить устройство ${deviceId}?`);

                if (confirmDelete) {
                    // Удаляем устройство из массива
                    const index = devices.findIndex(d => d.id === deviceId);
                    if (index !== -1) {
                        devices.splice(index, 1);
                        populateDevicesList();
                    }
                }
            });
        });
    }

    // Создание календаря
    function createCalendar(year, month, calendarElement, selectedDate) {
        const today = new Date();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        // Корректировка дня недели (0 - Воскресенье, 1 - Понедельник, ...)
        // Для России и многих европейских стран неделя начинается с понедельника
        const firstDayIndex = (firstDay.getDay() + 6) % 7; // Преобразуем 0 (воскресенье) в 6, а 1 (понедельник) в 0

        // Устанавливаем заголовок календаря
        const months = [
            'январь', 'февраль', 'март', 'апрель', 'май', 'июнь',
            'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'
        ];
        calendarElement.querySelector('h3').textContent = `${months[month]} ${year}`;

        // Генерируем дни
        const daysContainer = calendarElement.querySelector('.days');
        daysContainer.innerHTML = '';

        // Добавляем пустые ячейки для выравнивания по дням недели
        for (let i = 0; i < firstDayIndex; i++) {
            const dayElement = document.createElement('div');
            dayElement.classList.add('empty');
            daysContainer.appendChild(dayElement);
        }

        // Добавляем дни месяца
        for (let i = 1; i <= daysInMonth; i++) {
            const dayElement = document.createElement('div');
            dayElement.textContent = i;

            // Выделяем текущий день
            if (
                year === today.getFullYear() &&
                month === today.getMonth() &&
                i === today.getDate()
            ) {
                dayElement.classList.add('current');
            }

            // Выделяем выбранный день
            if (
                selectedDate &&
                year === selectedDate.getFullYear() &&
                month === selectedDate.getMonth() &&
                i === selectedDate.getDate()
            ) {
                dayElement.classList.add('selected');
            }

            // Обработчик клика на день
            dayElement.addEventListener('click', function() {
                // Удаляем класс выбранного дня у всех элементов
                daysContainer.querySelectorAll('.selected').forEach(el => {
                    el.classList.remove('selected');
                });

                // Добавляем класс выбранного дня к текущему элементу
                this.classList.add('selected');

                // Сохраняем выбранную дату
                const selectedDate = new Date(year, month, i);
                const formattedDate = `${i.toString().padStart(2, '0')}.${(month + 1).toString().padStart(2, '0')}.${year}`;

                // Устанавливаем значение в поле ввода
                if (calendarElement === fromDateCalendar) {
                    fromDateInput.value = formattedDate;
                    fromDateCalendar.style.display = 'none';
                } else if (calendarElement === toDateCalendar) {
                    toDateInput.value = formattedDate;
                    toDateCalendar.style.display = 'none';
                }
            });

            daysContainer.appendChild(dayElement);
        }
    }

    // Инициализируем обработчики событий

    // Если у нас есть кнопка для открытия модального окна устройств, добавляем обработчик
    const openDevicesBtn = document.getElementById('openDevicesModal');
    if (openDevicesBtn) {
        openDevicesBtn.addEventListener('click', function() {
            populateDevicesList();
            openModal(devicesModal);
        });
    }

    // Кнопки закрытия модальных окон
    closeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.device-modal');
            closeModal(modal);
        });
    });

    // Закрытие модального окна устройств
    if (closeDevicesBtn) {
        closeDevicesBtn.addEventListener('click', function() {
            closeModal(devicesModal);
        });
    }

    // Кнопка добавления устройства
    if (addDeviceBtn) {
        addDeviceBtn.addEventListener('click', function() {
            closeModal(devicesModal);
            openModal(addDeviceModal);
        });
    }

    // Поля выбора даты
    if (fromDateInput && fromDateCalendar) {
        fromDateInput.addEventListener('click', function() {
            // Показываем календарь для начальной даты
            fromDateCalendar.style.display = 'block';
            if (toDateCalendar) toDateCalendar.style.display = 'none';

            // Создаем календарь на текущий месяц
            const today = new Date();
            createCalendar(today.getFullYear(), today.getMonth(), fromDateCalendar, null);
        });
    }

    if (toDateInput && toDateCalendar) {
        toDateInput.addEventListener('click', function() {
            // Показываем календарь для конечной даты
            toDateCalendar.style.display = 'block';
            if (fromDateCalendar) fromDateCalendar.style.display = 'none';

            // Создаем календарь на текущий месяц
            const today = new Date();
            createCalendar(today.getFullYear(), today.getMonth(), toDateCalendar, null);
        });
    }

    // Применение выбранных дат
    if (applyDatesBtn) {
        applyDatesBtn.addEventListener('click', function() {
            alert(`Применены даты: от ${fromDateInput.value} до ${toDateInput.value}`);
            // Здесь был бы код для фильтрации логов по датам
        });
    }

    // Кнопки "Ок" для закрытия модальных окон
    if (okLogBtn) {
        okLogBtn.addEventListener('click', function() {
            closeModal(logModal);
            openModal(devicesModal);
        });
    }

    if (okAndroidBtn) {
        okAndroidBtn.addEventListener('click', function() {
            closeModal(androidAppsModal);
            openModal(devicesModal);
        });
    }

    if (okQrBtn) {
        okQrBtn.addEventListener('click', function() {
            closeModal(qrCodeModal);
            openModal(androidAppsModal);
        });
    }

    // Копирование ключа QR-кода
    if (copyQrKeyBtn) {
        copyQrKeyBtn.addEventListener('click', function() {
            const qrKeyInput = document.getElementById('qrKeyInput');
            if (qrKeyInput) {
                qrKeyInput.select();
                document.execCommand('copy');
                alert('Ключ скопирован!');
            }
        });
    }

    // Кнопки закрытия модальных окон редактирования и добавления
    if (closeEditBtn) {
        closeEditBtn.addEventListener('click', function() {
            closeModal(editDeviceModal);
            openModal(devicesModal);
        });
    }

    if (closeAddBtn) {
        closeAddBtn.addEventListener('click', function() {
            closeModal(addDeviceModal);
            openModal(devicesModal);
        });
    }

    // Обработка сохранения изменений при редактировании устройства
    document.querySelector('#editDeviceModal .device-save-btn')?.addEventListener('click', function() {
        const deviceId = document.querySelector('#editDeviceModal .device-id').textContent;
        const newName = document.getElementById('deviceNameInput').value;

        // Обновляем имя устройства в массиве
        const device = devices.find(d => d.id === deviceId);
        if (device) {
            device.name = newName;
            populateDevicesList();
        }

        closeModal(editDeviceModal);
        openModal(devicesModal);
    });

    // Обработка отмены изменений при редактировании устройства
    document.querySelector('#editDeviceModal .device-cancel-btn')?.addEventListener('click', function() {
        closeModal(editDeviceModal);
        openModal(devicesModal);
    });

    // Обработка сохранения при добавлении нового устройства
    document.querySelector('#addDeviceModal .device-save-btn')?.addEventListener('click', function() {
        const newName = document.getElementById('newDeviceNameInput').value;

        if (newName.trim() !== '') {
            // Генерируем случайный ID
            const newId = Math.random().toString(36).substring(2, 10) + '...';

            // Добавляем новое устройство в массив
            devices.push({ id: newId, name: newName });

            // Очищаем поле ввода
            document.getElementById('newDeviceNameInput').value = '';

            // Обновляем список устройств
            populateDevicesList();
        }

        closeModal(addDeviceModal);
        openModal(devicesModal);
    });

    // Обработка отмены при добавлении нового устройства
    document.querySelector('#addDeviceModal .device-cancel-btn')?.addEventListener('click', function() {
        // Очищаем поле ввода
        document.getElementById('newDeviceNameInput').value = '';

        closeModal(addDeviceModal);
        openModal(devicesModal);
    });

    // Закрытие календаря при клике вне его
    document.addEventListener('click', function(event) {
        if (fromDateCalendar && !fromDateCalendar.contains(event.target) && event.target !== fromDateInput) {
            fromDateCalendar.style.display = 'none';
        }

        if (toDateCalendar && !toDateCalendar.contains(event.target) && event.target !== toDateInput) {
            toDateCalendar.style.display = 'none';
        }
    });

    // Добавляем QR-код
    const qrCodeImage = document.getElementById('qrCodeImage');
    if (qrCodeImage) {
        // Копируем QR-код из архива
        fetch('extracted/sdnfdslkfd/device-management-modals/src/qr-code.png')
            .then(response => {
                if (response.ok) {
                    qrCodeImage.src = 'extracted/sdnfdslkfd/device-management-modals/src/qr-code.png';
                }
            })
            .catch(error => {
                console.error('Ошибка загрузки QR-кода:', error);
            });
    }

    // Инициализация кнопок для открытия QR-кода
    document.querySelectorAll('.device-qr-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            closeModal(androidAppsModal);
            openModal(qrCodeModal);
        });
    });
}

// Инициализация модальных окон после загрузки страницы
document.addEventListener('DOMContentLoaded', function() {
    initDeviceManagementModals();
});
